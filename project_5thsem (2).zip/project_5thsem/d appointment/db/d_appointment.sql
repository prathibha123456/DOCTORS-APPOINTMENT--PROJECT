-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 12, 2016 at 06:44 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `d_appointment`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `A_Id` int(50) NOT NULL auto_increment,
  `P_id` int(50) NOT NULL,
  `A_Time` varchar(100) NOT NULL,
  `A_Date` varchar(100) NOT NULL,
  `D_id` int(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY  (`A_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=109 ;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`A_Id`, `P_id`, `A_Time`, `A_Date`, `D_id`, `status`) VALUES
(2, 11, '8', '23-5-2012', 12, ''),
(98, 99, '10', '1-1-2014', 88, ''),
(99, 11, '2014-12-22', 'we', 12, ''),
(100, 424, '2014-12-22', '8am', 123, ''),
(101, 11, '2014-12-22', '9pm', 12, ''),
(102, 11, '2014-12-22', '9am', 12, ''),
(103, 11, '2014-12-22', '9am', 12, ''),
(104, 102, '2014-12-22', '11am', 15, 'appointed'),
(105, 102, '2014-12-24', '2pm', 17, 'appointed'),
(106, 102, 'none', 'none', 14, 'pending'),
(107, 102, 'none', 'none', 16, 'pending'),
(108, 102, '2014-12-24', '9pm', 17, 'appointed');

-- --------------------------------------------------------

--
-- Table structure for table `bill_details`
--

CREATE TABLE `bill_details` (
  `bill_id` int(11) NOT NULL auto_increment,
  `patient_id` int(50) NOT NULL,
  `amount` int(100) NOT NULL,
  `bill_date` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY  (`bill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `bill_details`
--

INSERT INTO `bill_details` (`bill_id`, `patient_id`, `amount`, `bill_date`, `status`) VALUES
(1, 349, 5000, '2014-1-1', 'none'),
(2, 0, 5000, '2014-1-1', 'none'),
(3, 0, 500, '2014-12-21', 'none'),
(4, 102, 500, '2014-12-21', 'none'),
(5, 102, 5000, '2014-12-22', 'none'),
(6, 101, 9, '2015/4/4', 'none'),
(7, 10, 8888, '2013/3/3', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_details`
--

CREATE TABLE `doctor_details` (
  `D_id` int(50) NOT NULL auto_increment,
  `D_Name` varchar(100) NOT NULL,
  `Designation` varchar(200) NOT NULL,
  `Experiance` varchar(100) NOT NULL,
  `Achievament` varchar(200) NOT NULL,
  `Address` varchar(300) NOT NULL,
  `Mobile_no` varchar(100) NOT NULL,
  `Email_id` varchar(100) NOT NULL,
  `Age` varchar(100) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  PRIMARY KEY  (`D_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `doctor_details`
--

INSERT INTO `doctor_details` (`D_id`, `D_Name`, `Designation`, `Experiance`, `Achievament`, `Address`, `Mobile_no`, `Email_id`, `Age`, `Gender`) VALUES
(12, 'Ankush', 'pqr', '10years', 'mno', 'Belgaum', '9843567321', 'ankush@gmail.com', '55', 'male'),
(14, 'Arush', 'abc', '5years', 'xyz', 'mno', '7869543298', 'arush@gmail.com', '34', 'male'),
(15, 'Manzoor', 'Dental', '5', 'achievement', 'Dharwad', '9876543211', 'venture.manzoor@gmail.com', '26', 'male'),
(16, 'rutuja', 'MD', '2', 'achievement', 'Borgan', '9876543211', 'rutuja@gmail.com', '20', 'female'),
(17, 'sonali', 'abc', '4', 'xyz', 'Ankali', '4567873456', 'sonali@gmail.com', '20', 'female');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `User_name` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Type` varchar(200) NOT NULL,
  `Hint_question` varchar(200) NOT NULL,
  `Hint_answer` varchar(200) NOT NULL,
  `Status` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`User_name`, `Password`, `Type`, `Hint_question`, `Hint_answer`, `Status`) VALUES
('admin', '123123', 'admin', 'who i am?', 'admin', 'Active'),
('15', '9876543211', 'doctor', 'whats my login name', '15', 'active'),
('101', '9876543211', 'patient', 'whats my login name', '101', 'active'),
('201', '8884082084', 'homeomedicare', 'whats my login name', '201', 'active'),
('bill', '123', 'bill', 'h', 'a', 'active'),
('602', '9999999', 'user', 'whats my login name', '602', 'active'),
('16', '9876543211', 'doctor', 'whats my login name', '16', 'active'),
('17', '4567873456', 'doctor', 'whats my login name', '17', 'active'),
('102', '9535719285', 'patient', 'whats my login name', '102', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `madicine_details`
--

CREATE TABLE `madicine_details` (
  `M_Id` int(50) NOT NULL auto_increment,
  `M_Name` varchar(100) NOT NULL,
  `Content` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Mfg_Date` varchar(50) NOT NULL,
  `Exp_Date` varchar(50) NOT NULL,
  PRIMARY KEY  (`M_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=327 ;

--
-- Dumping data for table `madicine_details`
--

INSERT INTO `madicine_details` (`M_Id`, `M_Name`, `Content`, `Description`, `Mfg_Date`, `Exp_Date`) VALUES
(22, 'vix', 'abc', 'xyz', '20-10-2014', '20-10-2015'),
(325, 'vix', 'abc', 'abc23', '2012-10-12', '2012-12-12'),
(326, 'Omez', 'xyz', 'abc', '2014-12-9', '2015-12-9');

-- --------------------------------------------------------

--
-- Table structure for table `medicare_time`
--

CREATE TABLE `medicare_time` (
  `M_T_Id` int(50) NOT NULL auto_increment,
  `Start_Time` varchar(100) NOT NULL,
  `End_Time` varchar(50) NOT NULL,
  `Holiday_days` varchar(50) NOT NULL,
  PRIMARY KEY  (`M_T_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `medicare_time`
--

INSERT INTO `medicare_time` (`M_T_Id`, `Start_Time`, `End_Time`, `Holiday_days`) VALUES
(2, '8am', '8pm', 'sunday'),
(3, '8am', '9pm', 'sunday'),
(4, '9am', '6pm', 'monday');

-- --------------------------------------------------------

--
-- Table structure for table `medicine_to_patient`
--

CREATE TABLE `medicine_to_patient` (
  `M_To_P_Id` int(50) NOT NULL auto_increment,
  `D_id` int(50) NOT NULL,
  `P_id` int(50) NOT NULL,
  `M_Id` int(50) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  `Howtotake` varchar(200) NOT NULL,
  `Date` varchar(100) NOT NULL,
  PRIMARY KEY  (`M_To_P_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=350 ;

--
-- Dumping data for table `medicine_to_patient`
--

INSERT INTO `medicine_to_patient` (`M_To_P_Id`, `D_id`, `P_id`, `M_Id`, `Quantity`, `Howtotake`, `Date`) VALUES
(234, 12, 11, 234, '890', 'xyz', '2014-12-9'),
(346, 12, 11, 346, '100', 'qqqqq', '2014-12-9'),
(347, 12, 346, 326, '544', 'abc', '2014-12-9'),
(348, 12, 11, 326, '20', 'abc', '2014-12-11'),
(349, 12, 346, 22, '10', 'fgfg', '2014-12-9');

-- --------------------------------------------------------

--
-- Table structure for table `patient_checkup_report`
--

CREATE TABLE `patient_checkup_report` (
  `P_C_R_Id` int(50) NOT NULL auto_increment,
  `P_id` int(50) NOT NULL,
  `D_id` int(50) NOT NULL,
  `C_U_Time` varchar(100) NOT NULL,
  `C_U_Date` varchar(100) NOT NULL,
  `Diseases_Info` varchar(100) NOT NULL,
  `Precotion_Info` varchar(200) NOT NULL,
  `Course_Details` varchar(300) NOT NULL,
  `Next_Appointment_Date` varchar(100) NOT NULL,
  PRIMARY KEY  (`P_C_R_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `patient_checkup_report`
--

INSERT INTO `patient_checkup_report` (`P_C_R_Id`, `P_id`, `D_id`, `C_U_Time`, `C_U_Date`, `Diseases_Info`, `Precotion_Info`, `Course_Details`, `Next_Appointment_Date`) VALUES
(12, 11, 12, '10am', '12-3-14', 'qwer', 'abc', 'sdf', '12-4-14'),
(13, 346, 13, '9pm', '2014-12-9', 'xyz', 'mno', 'MBBS', '2014-1-9'),
(14, 11, 12, '9am', '2014-12-9', 'abc', 'xyz', 'MBBS', '2014-1-9'),
(15, 349, 15, '11', '2014-12-20', 'Diabetes', 'tabs', '10days', '2014-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `P_id` int(50) NOT NULL auto_increment,
  `P_NO` varchar(100) NOT NULL,
  `P_Name` varchar(200) NOT NULL,
  `DateOfBirth` varchar(100) NOT NULL,
  `Address` varchar(500) NOT NULL,
  `Gender` varchar(200) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `Email_Id` varchar(100) NOT NULL,
  `Reg_Date` varchar(200) NOT NULL,
  PRIMARY KEY  (`P_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=352 ;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`P_id`, `P_NO`, `P_Name`, `DateOfBirth`, `Address`, `Gender`, `contact_no`, `Email_Id`, `Reg_Date`) VALUES
(11, '10', 'anand', '2000-2-21', 'dwd', 'male', '9829445687', 'anand@gmail.com', '2014-12-7'),
(349, '101', 'Arati', '1994-9-23', 'chikodi', 'female', '9876354623', 'aratii@gmail.com', '2014-12-20'),
(351, '102', 'Sanjana', '2000-2-21', 'dwd', 'female', '9829445687', 'sanj@gmail.com', '2014-12-7');

-- --------------------------------------------------------

--
-- Table structure for table `patient_health_report`
--

CREATE TABLE `patient_health_report` (
  `P_H_R_id` int(50) NOT NULL auto_increment,
  `P_id` int(50) NOT NULL,
  `Report` varchar(500) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `Upload_Date` varchar(100) NOT NULL,
  PRIMARY KEY  (`P_H_R_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=326604 ;

--
-- Dumping data for table `patient_health_report`
--

INSERT INTO `patient_health_report` (`P_H_R_id`, `P_id`, `Report`, `Description`, `Upload_Date`) VALUES
(326596, 11, 'abc', 'mno', '25-7-1988'),
(326597, 11, 'good', 'xyz', '2014-12-17'),
(326598, 346, 'adsa', 'abc', '2014-12-8'),
(326599, 349, 'report', 'Description', '2014-12-20'),
(326603, 102, 'normal', 'normal', '2014-12-21');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `Service_id` int(50) NOT NULL auto_increment,
  `Service_Name` varchar(100) NOT NULL,
  `Description` varchar(200) NOT NULL,
  PRIMARY KEY  (`Service_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`Service_id`, `Service_Name`, `Description`) VALUES
(4, 'pooja', 'abc'),
(5, 'SRP', 'xyz'),
(6, 'asd', 'dfger'),
(7, 'lmn', 'pqr'),
(8, 'lmn', 'mno'),
(9, 'pooja', 'rst');

-- --------------------------------------------------------

--
-- Table structure for table `treatement_achivements`
--

CREATE TABLE `treatement_achivements` (
  `T_A_id` int(50) NOT NULL auto_increment,
  `T_A_Title` varchar(200) NOT NULL,
  `T_A_Description` varchar(300) NOT NULL,
  `Duration` varchar(200) NOT NULL,
  `Image` varchar(100) NOT NULL,
  PRIMARY KEY  (`T_A_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3561 ;

--
-- Dumping data for table `treatement_achivements`
--

INSERT INTO `treatement_achivements` (`T_A_id`, `T_A_Title`, `T_A_Description`, `Duration`, `Image`) VALUES
(3556, 'treatment', 'Achievement', '2years', 'Chrysanthemum.jpg'),
(3558, 'treatment', 'achievement', '12', 'Chrysanthemum.jpg'),
(3559, 'Agadi', 'abcdefg', '8', 'VINOD C.docx'),
(3560, 'title', 'Achievements', '6months', 'OM.jpg');
