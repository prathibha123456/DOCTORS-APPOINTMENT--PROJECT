<?php include('header.php'); ?>

<?php include('top_menu.php'); ?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>


<div id="content">
<?php include('sidebar_menu.php'); ?>
<form method="post" action="fecilities_insert.php" name="formID" id="formID">
	<table width="395" border="0">
  <tr>
    <td colspan="3">Add Facility </td>
    </tr>
  <tr>
    <td width="123">Facility Name </td>
    <td width="169"><input name="fecility_name" type="text" id="fecility_name" class="validate[required,custom[onlyLetter]]"></td>
    <td width="89">&nbsp;</td>
  </tr>
  <tr>
    <td> Description </td>
    <td><textarea name="fecility_desc" id="fecility_desc" class="validate[required]"></textarea></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Submit"></td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>
<?php include('footer.php'); ?>