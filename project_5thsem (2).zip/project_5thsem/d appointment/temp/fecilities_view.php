<?php include('header.php'); ?>

<?php include('top_menu.php'); ?>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>


<div id="content">
<?php include('sidebar_menu.php'); ?>
	<div class="full_w">
<div align="center">
<h1 style="color:#5B5B5B">&nbsp;</h1>
<table width="100%" height="174">
  <tbody>
    <tr>
      <td height="35" colspan="4"><div align="center" class="style1">HOSTEL FACILITIES</div></td>
      </tr>
    <tr>
      <td height="35"><a href="fecilities_form.php"><img src="img/add1.png" width="30" height="30"/></a></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      </tr>
    <tr>
      <td width="160" height="35"><center>
        Facilities
      </center></td>
      <td width="202"><center>
    Facilities Description
      </center></td>
      <td width="121">Edit</td>
      <td width="121"><center>
        Delete
      </center></td>
      </tr>
	   <?php 
	   include('../dbconnection.php');
		$sql=mysql_query("Select * from fecilities");
		while($row=mysql_fetch_array($sql)){
		?>
    <tr>
      <td height="57"><center><?php echo $row['fecility_name'];?></center></td>
      <td><center>
          <?php echo $row['fecility_desc'];?>
      </center></td>
      <td><a href="fecilities_edit.php?id=<?php echo $row['fecility_id'];?>"><img src="img/document_edit.png" width="30" height="30"/></a></td>
      <td><center>
       <a href="fecilities_delete.php?id=<?php echo $row['fecility_id'];?>"><img src="img/delete.png" width="30" height="30"/></a>      
      </center></td>
      </tr>
	  <?php }?>
  </tbody>
</table>
</div>
<?php include('footer.php'); ?>