package d_appointment;
import java.sql.*;
public class dbconnect
{
	private Connection con;
	public Statement stmt;
	public String getconn()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("Jdbc:Odbc:prat");
			stmt=con.createStatement();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return"";
	}
}
